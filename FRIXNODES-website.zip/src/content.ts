/** FRIXNODES hosting website content. */
export const brand = { name: 'Frixnodes', wordmark: 'FRIXNODES', email: 'sales@frixnodes.com' };
export const nav = [
  {label: 'Overview', href: '#log'}, {label: 'Infrastructure', href: '#trajectory'},
  {label: 'Services', href: '#missions'}, {label: 'Get started', href: '#reserve'},
];
export const hero = {
  title: 'HOST WITHOUT LIMITS',
  kicker: 'Performance infrastructure. Built for what you run.',
  site: 'VPS · GAME SERVERS · BOT HOSTING · WEB HOSTING',
};
export const intro = {
  eyebrow: 'Why Frixnodes',
  heading: 'Your projects deserve serious infrastructure.',
  body: 'From high-performance virtual machines to lag-free Minecraft worlds, always-on bots and fast websites — deploy with confidence on infrastructure built to keep you moving.',
};
export const log = [
  {tag: '01 / COMPUTE', title: 'VPS Hosting', body: 'Dedicated resources, NVMe storage and full root access for apps, workloads and production projects.', image: '/media/cards/m1-launch.webp'},
  {tag: '02 / GAMING', title: 'Minecraft Hosting', body: 'Power your SMP, network or community with reliable performance and the control your server needs.', image: '/media/cards/m2-orbit.webp'},
  {tag: '03 / AUTOMATION', title: 'Bot Hosting', body: 'Keep Discord bots, automation and background services online around the clock.', image: '/media/cards/m3-base.webp'},
  {tag: '04 / WEB', title: 'Web Hosting', body: 'Launch business sites, portfolios and web applications with a fast, dependable home.', image: '/media/cards/m4-walk.webp'},
];
export const trajectory = {
  eyebrow: 'Our infrastructure',
  heading: 'A reliable route from idea to online.',
  legs: [
    {day: '01', title: 'Choose your service', body: 'Pick the platform that fits your project — VPS, Minecraft, bot or web hosting.'},
    {day: '02', title: 'Deploy your workload', body: 'Get the resources and environment you need to configure your project your way.'},
    {day: '03', title: 'Scale with confidence', body: 'Grow your resources as your community, traffic or workload expands.'},
    {day: '04', title: 'Stay online', body: 'Manage your services and keep your project moving with Frixnodes.'},
  ],
};
export const missions = {
  eyebrow: 'Our services', heading: 'Find your perfect hosting.',
  note: 'Four services. One place to build.',
  items: [
    {name: 'VPS Hosting', days: 1, lines: ['NVMe-powered storage', 'Full root access', 'Flexible compute resources'], cta: 'Explore VPS'},
    {name: 'Minecraft Hosting', days: 2, lines: ['Game-ready performance', 'Panel-based management', 'Built for SMPs and networks'], cta: 'Explore Minecraft', featured: true},
    {name: 'Bot Hosting', days: 3, lines: ['24/7 bot uptime', 'Python and Node.js projects', 'Simple deployment workflow'], cta: 'Explore Bot Hosting'},
    {name: 'Web Hosting', days: 4, lines: ['Fast website delivery', 'For sites and web apps', 'Simple and reliable hosting'], cta: 'Explore Web Hosting'},
  ],
};
export const reserve = {
  eyebrow: 'Get started', heading: 'Let’s get your project online.',
  body: 'Tell us what you are looking to host. Our team can help you find the right Frixnodes service for your project.',
  window: '2035-01-01T00:00:00Z', windowLabel: 'Frixnodes · Always building',
};
